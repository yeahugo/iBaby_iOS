//
//  AiDefaultSearchView.h
//  iBaby
//
//  Created by yeahugo on 14-5-18.
//  Copyright (c) 2014年 Ai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AiDefaultSearchView : UIView

@end
