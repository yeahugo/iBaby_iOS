//
//  AiFeedbackViewController.h
//  iBaby
//
//  Created by yeahugo on 14-5-25.
//  Copyright (c) 2014年 Ai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AiFeedbackViewController : UIViewController

-(IBAction)closeFeedback:(id)sender;
@end
